import { createClient } from "@supabase/supabase-js"
import AsyncStorage from "@react-native-async-storage/async-storage"
import { Platform } from "react-native"

const supabaseUrl = "YOUR_SUPABASE_URL"
const supabaseAnonKey = "YOUR_SUPABASE_ANON_KEY"

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    ...(Platform.OS !== "web" ? { storage: AsyncStorage } : {}),
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
})

// Generate reference number
export const generateReferenceNumber = (type: "order" | "change" | "worker"): string => {
  const prefix = type === "order" ? "ORD" : type === "change" ? "CHG" : "WRK"
  const random = Math.random().toString(36).substring(2, 7).toUpperCase()
  return `${prefix}${random}`
}

// Upload file to Supabase Storage
export const uploadFile = async (file: any, bucket: string, path: string) => {
  try {
    const { data, error } = await supabase.storage.from(bucket).upload(path, file)

    if (error) throw error
    return data
  } catch (error) {
    console.error("Error uploading file:", error)
    throw error
  }
}
