export interface User {
  id: string
  email: string
  full_name?: string
  role: "client" | "agent" | "worker" | "god"
  created_at: string
  updated_at: string
}

export interface Order {
  id: string
  reference_number: string
  client_id?: string
  full_name: string
  email: string
  module_name: string
  word_count: number
  deadline: string
  additional_guidance?: string
  status: "processing" | "reviewing" | "done"
  created_at: string
  updated_at: string
}

export interface OrderFile {
  id: string
  order_id: string
  file_name: string
  file_path: string
  file_size?: number
  file_type?: string
  created_at: string
}

export interface Change {
  id: string
  order_id: string
  email: string
  notes: string
  deadline_changes?: string
  created_at: string
}

export interface WorkerSubmission {
  id: string
  order_id: string
  email: string
  notes: string
  created_at: string
}
