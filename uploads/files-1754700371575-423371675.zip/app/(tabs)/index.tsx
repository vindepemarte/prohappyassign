import { View, Text, StyleSheet, ScrollView, Image, SafeAreaView } from "react-native"
import { CustomButton } from "../../components/CustomButton"
import { router } from "expo-router"

export default function HomeScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Header */}
        <View style={styles.header}>
          <Image source={require("../../assets/logo.png")} style={styles.logo} />
          <Text style={styles.title}>Assignment Assistance</Text>
          <Text style={styles.subtitle}>Your Academic Success Partner</Text>
        </View>

        {/* Hero Section */}
        <View style={styles.heroSection}>
          <View style={styles.statsContainer}>
            <View style={styles.statItem}>
              <Text style={styles.statNumber}>100%</Text>
              <Text style={styles.statLabel}>Pass Rate</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statNumber}>100%</Text>
              <Text style={styles.statLabel}>No AI</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statNumber}>0%</Text>
              <Text style={styles.statLabel}>Risk</Text>
            </View>
          </View>

          <Text style={styles.description}>
            We offer assignment assistance all over UK with our specialised workers. Trusted since 2017 with guaranteed
            quality and authenticity.
          </Text>

          <View style={styles.featuresContainer}>
            <View style={styles.feature}>
              <Text style={styles.featureIcon}>🎓</Text>
              <Text style={styles.featureText}>Expert Writers</Text>
            </View>
            <View style={styles.feature}>
              <Text style={styles.featureIcon}>⏰</Text>
              <Text style={styles.featureText}>On-Time Delivery</Text>
            </View>
            <View style={styles.feature}>
              <Text style={styles.featureIcon}>🔒</Text>
              <Text style={styles.featureText}>100% Confidential</Text>
            </View>
            <View style={styles.feature}>
              <Text style={styles.featureIcon}>💯</Text>
              <Text style={styles.featureText}>Quality Guaranteed</Text>
            </View>
          </View>
        </View>

        {/* CTA Button */}
        <View style={styles.ctaContainer}>
          <CustomButton
            title="START NOW"
            onPress={() => router.push("/forms")}
            style={styles.ctaButton}
            textStyle={styles.ctaButtonText}
          />
          <Text style={styles.ctaSubtext}>Join thousands of successful students</Text>
        </View>

        {/* Trust Indicators */}
        <View style={styles.trustSection}>
          <Text style={styles.trustTitle}>Trusted Since 2017</Text>
          <Text style={styles.trustDescription}>
            Over 10,000 successful assignments completed with 100% satisfaction rate
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8FAFC",
  },
  scrollContent: {
    paddingBottom: 40,
  },
  header: {
    alignItems: "center",
    paddingTop: 40,
    paddingHorizontal: 20,
    backgroundColor: "#3B82F6",
    paddingBottom: 40,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  logo: {
    width: 80,
    height: 80,
    marginBottom: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    color: "white",
    textAlign: "center",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: "#DBEAFE",
    textAlign: "center",
  },
  heroSection: {
    paddingHorizontal: 20,
    paddingTop: 32,
  },
  statsContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    backgroundColor: "white",
    borderRadius: 16,
    paddingVertical: 24,
    marginBottom: 24,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  statItem: {
    alignItems: "center",
  },
  statNumber: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#EF4444",
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: "#6B7280",
    fontWeight: "600",
  },
  description: {
    fontSize: 16,
    color: "#374151",
    textAlign: "center",
    lineHeight: 24,
    marginBottom: 32,
  },
  featuresContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    marginBottom: 32,
  },
  feature: {
    width: "48%",
    backgroundColor: "white",
    borderRadius: 12,
    padding: 16,
    alignItems: "center",
    marginBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  featureIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  featureText: {
    fontSize: 14,
    fontWeight: "600",
    color: "#374151",
    textAlign: "center",
  },
  ctaContainer: {
    paddingHorizontal: 20,
    alignItems: "center",
    marginBottom: 32,
  },
  ctaButton: {
    width: "100%",
    backgroundColor: "#FBBF24",
    marginBottom: 12,
  },
  ctaButtonText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#1F2937",
  },
  ctaSubtext: {
    fontSize: 14,
    color: "#6B7280",
    textAlign: "center",
  },
  trustSection: {
    paddingHorizontal: 20,
    alignItems: "center",
  },
  trustTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#1F2937",
    marginBottom: 8,
  },
  trustDescription: {
    fontSize: 14,
    color: "#6B7280",
    textAlign: "center",
    lineHeight: 20,
  },
})
