"use client"

import { useState, useEffect } from "react"
import { View, Text, StyleSheet, ScrollView, SafeAreaView, RefreshControl, TouchableOpacity } from "react-native"
import { supabase } from "../../lib/supabase"
import type { Order } from "../../types"

export default function AssignmentsScreen() {
  const [assignments, setAssignments] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [filter, setFilter] = useState<"all" | "processing" | "reviewing" | "done">("all")

  useEffect(() => {
    fetchAssignments()
  }, [])

  const fetchAssignments = async () => {
    try {
      const { data, error } = await supabase.from("orders").select("*").order("created_at", { ascending: false })

      if (error) throw error
      setAssignments(data || [])
    } catch (error) {
      console.error("Error fetching assignments:", error)
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  const onRefresh = () => {
    setRefreshing(true)
    fetchAssignments()
  }

  const filteredAssignments = assignments.filter((assignment) => filter === "all" || assignment.status === filter)

  const getStatusColor = (status: string) => {
    switch (status) {
      case "processing":
        return "#FBBF24"
      case "reviewing":
        return "#3B82F6"
      case "done":
        return "#10B981"
      default:
        return "#6B7280"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "processing":
        return "⏳"
      case "reviewing":
        return "👀"
      case "done":
        return "✅"
      default:
        return "📋"
    }
  }

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text>Loading assignments...</Text>
        </View>
      </SafeAreaView>
    )
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>My Assignments</Text>
        <Text style={styles.subtitle}>Track your assignment progress</Text>
      </View>

      {/* Filter Tabs */}
      <View style={styles.filterContainer}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {["all", "processing", "reviewing", "done"].map((status) => (
            <TouchableOpacity
              key={status}
              style={[styles.filterTab, filter === status && styles.activeFilterTab]}
              onPress={() => setFilter(status as any)}
            >
              <Text style={[styles.filterText, filter === status && styles.activeFilterText]}>
                {status === "all" ? "All" : status.charAt(0).toUpperCase() + status.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {filteredAssignments.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyIcon}>📚</Text>
            <Text style={styles.emptyTitle}>No Assignments</Text>
            <Text style={styles.emptyText}>
              {filter === "all"
                ? "Your assignments will appear here once you submit them"
                : `No assignments with status "${filter}"`}
            </Text>
          </View>
        ) : (
          filteredAssignments.map((assignment) => (
            <View key={assignment.id} style={styles.assignmentCard}>
              <View style={styles.assignmentHeader}>
                <Text style={styles.referenceNumber}>{assignment.reference_number}</Text>
                <View style={[styles.statusBadge, { backgroundColor: getStatusColor(assignment.status) }]}>
                  <Text style={styles.statusText}>
                    {getStatusIcon(assignment.status)} {assignment.status.toUpperCase()}
                  </Text>
                </View>
              </View>

              <View style={styles.assignmentDetails}>
                <Text style={styles.moduleName}>{assignment.module_name}</Text>
                <Text style={styles.assignmentInfo}>
                  📊 {assignment.word_count} words • 📅 Due: {new Date(assignment.deadline).toLocaleDateString()}
                </Text>
                <Text style={styles.submittedDate}>
                  Submitted: {new Date(assignment.created_at).toLocaleDateString()}
                </Text>
              </View>

              <View style={styles.progressContainer}>
                <View style={styles.progressBar}>
                  <View
                    style={[
                      styles.progressFill,
                      {
                        width:
                          assignment.status === "processing"
                            ? "33%"
                            : assignment.status === "reviewing"
                              ? "66%"
                              : "100%",
                        backgroundColor: getStatusColor(assignment.status),
                      },
                    ]}
                  />
                </View>
                <Text style={styles.progressText}>
                  {assignment.status === "processing"
                    ? "In Progress"
                    : assignment.status === "reviewing"
                      ? "Under Review"
                      : "Completed"}
                </Text>
              </View>
            </View>
          ))
        )}
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8FAFC",
  },
  header: {
    backgroundColor: "#3B82F6",
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "white",
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: "#DBEAFE",
  },
  filterContainer: {
    backgroundColor: "white",
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: "#E5E7EB",
  },
  filterTab: {
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 12,
    backgroundColor: "#F3F4F6",
  },
  activeFilterTab: {
    backgroundColor: "#3B82F6",
  },
  filterText: {
    fontSize: 14,
    fontWeight: "600",
    color: "#6B7280",
  },
  activeFilterText: {
    color: "white",
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  emptyContainer: {
    alignItems: "center",
    paddingVertical: 60,
  },
  emptyIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#1F2937",
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 16,
    color: "#6B7280",
    textAlign: "center",
    lineHeight: 24,
  },
  assignmentCard: {
    backgroundColor: "white",
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  assignmentHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  referenceNumber: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#1F2937",
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  statusText: {
    fontSize: 12,
    fontWeight: "600",
    color: "white",
  },
  assignmentDetails: {
    marginBottom: 16,
  },
  moduleName: {
    fontSize: 16,
    fontWeight: "600",
    color: "#1F2937",
    marginBottom: 8,
  },
  assignmentInfo: {
    fontSize: 14,
    color: "#6B7280",
    marginBottom: 4,
  },
  submittedDate: {
    fontSize: 12,
    color: "#9CA3AF",
  },
  progressContainer: {
    marginTop: 8,
  },
  progressBar: {
    height: 6,
    backgroundColor: "#E5E7EB",
    borderRadius: 3,
    marginBottom: 8,
  },
  progressFill: {
    height: "100%",
    borderRadius: 3,
  },
  progressText: {
    fontSize: 12,
    color: "#6B7280",
    textAlign: "center",
  },
})
