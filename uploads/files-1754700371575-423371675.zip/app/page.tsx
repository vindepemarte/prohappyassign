"use client"

import WorkerFormScreen from "forms/worker"

export default function SyntheticV0PageForDeployment() {
  return <WorkerFormScreen />
}