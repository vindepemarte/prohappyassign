"use client"

import { useState } from "react"
import { View, Text, StyleSheet, ScrollView, SafeAreaView, Alert } from "react-native"
import { CustomButton } from "../../components/CustomButton"
import { CustomInput } from "../../components/CustomInput"
import { FileUpload } from "../../components/FileUpload"
import { supabase, generateReferenceNumber } from "../../lib/supabase"
import { router } from "expo-router"
import type * as DocumentPicker from "expo-document-picker"

export default function ClientFormScreen() {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    moduleName: "",
    wordCount: "",
    deadline: "",
    additionalGuidance: "",
  })
  const [files, setFiles] = useState<DocumentPicker.DocumentPickerResult[]>([])
  const [loading, setLoading] = useState(false)

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const validateForm = () => {
    const { fullName, email, moduleName, wordCount, deadline } = formData

    if (!fullName.trim()) {
      Alert.alert("Error", "Please enter your full name")
      return false
    }

    if (!email.trim() || !email.includes("@")) {
      Alert.alert("Error", "Please enter a valid email address")
      return false
    }

    if (!moduleName.trim()) {
      Alert.alert("Error", "Please enter the module name")
      return false
    }

    if (!wordCount.trim() || isNaN(Number(wordCount)) || Number(wordCount) <= 0) {
      Alert.alert("Error", "Please enter a valid word count")
      return false
    }

    if (!deadline.trim()) {
      Alert.alert("Error", "Please enter the deadline")
      return false
    }

    return true
  }

  const handleSubmit = async () => {
    if (!validateForm()) return

    setLoading(true)
    try {
      const referenceNumber = generateReferenceNumber("order")

      // Insert order into database
      const { data: orderData, error: orderError } = await supabase
        .from("orders")
        .insert({
          reference_number: referenceNumber,
          full_name: formData.fullName,
          email: formData.email,
          module_name: formData.moduleName,
          word_count: Number.parseInt(formData.wordCount),
          deadline: formData.deadline,
          additional_guidance: formData.additionalGuidance || null,
          status: "processing",
        })
        .select()
        .single()

      if (orderError) throw orderError

      // Upload files if any
      if (files.length > 0) {
        for (const file of files) {
          if (file.type === "success") {
            // Upload file to Supabase Storage
            const filePath = `orders/${referenceNumber}/${file.name}`

            // Note: In a real implementation, you'd need to handle file upload properly
            // This is a simplified version
            const { error: fileError } = await supabase.from("order_files").insert({
              order_id: orderData.id,
              file_name: file.name,
              file_path: filePath,
              file_size: file.size,
              file_type: file.mimeType,
            })

            if (fileError) throw fileError
          }
        }
      }

      Alert.alert(
        "Success!",
        `Your order has been submitted successfully!\n\nReference Number: ${referenceNumber}\n\nPlease save this reference number for future communications.`,
        [
          {
            text: "OK",
            onPress: () => router.back(),
          },
        ],
      )
    } catch (error) {
      console.error("Error submitting order:", error)
      Alert.alert("Error", "Failed to submit order. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.content}>
          <Text style={styles.title}>Client Order Form</Text>
          <Text style={styles.subtitle}>Please fill in all required fields to submit your assignment</Text>

          <CustomInput
            label="👤 Full Name*"
            placeholder="Enter your full name"
            value={formData.fullName}
            onChangeText={(value) => handleInputChange("fullName", value)}
          />

          <CustomInput
            label="📧 Email Address*"
            placeholder="Enter your email address"
            value={formData.email}
            onChangeText={(value) => handleInputChange("email", value)}
            keyboardType="email-address"
            autoCapitalize="none"
          />

          <CustomInput
            label="📚 Module Name*"
            placeholder="Enter module name (e.g., CS101, MATH201)"
            value={formData.moduleName}
            onChangeText={(value) => handleInputChange("moduleName", value)}
          />

          <CustomInput
            label="📊 Word Count*"
            placeholder="0"
            value={formData.wordCount}
            onChangeText={(value) => handleInputChange("wordCount", value)}
            keyboardType="numeric"
          />

          <CustomInput
            label="📅 Order Deadline*"
            placeholder="dd/mm/yyyy"
            value={formData.deadline}
            onChangeText={(value) => handleInputChange("deadline", value)}
          />

          <FileUpload label="📎 Assignment Files" onFilesSelected={setFiles} maxFiles={5} />

          <CustomInput
            label="💡 Additional Guidance"
            placeholder="Enter any additional guidance or requirements for your assignment"
            value={formData.additionalGuidance}
            onChangeText={(value) => handleInputChange("additionalGuidance", value)}
            multiline
            numberOfLines={4}
            style={styles.textArea}
          />

          <CustomButton title="Submit Order" onPress={handleSubmit} disabled={loading} style={styles.submitButton} />
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8FAFC",
  },
  scrollContent: {
    paddingBottom: 40,
  },
  content: {
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#1F2937",
    textAlign: "center",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: "#6B7280",
    textAlign: "center",
    marginBottom: 32,
  },
  textArea: {
    height: 100,
    textAlignVertical: "top",
  },
  submitButton: {
    marginTop: 24,
    backgroundColor: "#FBBF24",
  },
})
