"use client"

import { useState, useEffect } from "react"
import { View, Text, StyleSheet, ScrollView, SafeAreaView, Alert } from "react-native"
import { CustomButton } from "../../components/CustomButton"
import { CustomInput } from "../../components/CustomInput"
import { FileUpload } from "../../components/FileUpload"
import { supabase } from "../../lib/supabase"
import { router, useLocalSearchParams } from "expo-router"
import type * as DocumentPicker from "expo-document-picker"

export default function ChangesFormScreen() {
  const { ref } = useLocalSearchParams<{ ref: string }>()
  const [formData, setFormData] = useState({
    email: "",
    referenceNumber: ref || "",
    notes: "",
    deadlineChanges: "",
  })
  const [files, setFiles] = useState<DocumentPicker.DocumentPickerResult[]>([])
  const [loading, setLoading] = useState(false)
  const [orderExists, setOrderExists] = useState(false)

  useEffect(() => {
    if (ref) {
      checkOrderExists(ref)
    }
  }, [ref])

  const checkOrderExists = async (referenceNumber: string) => {
    try {
      const { data, error } = await supabase
        .from("orders")
        .select("id")
        .eq("reference_number", referenceNumber)
        .single()

      if (data) {
        setOrderExists(true)
      } else {
        Alert.alert("Invalid Reference", "Order not found with this reference number")
        router.back()
      }
    } catch (error) {
      Alert.alert("Error", "Failed to verify reference number")
      router.back()
    }
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const validateForm = () => {
    const { email, notes } = formData

    if (!email.trim() || !email.includes("@")) {
      Alert.alert("Error", "Please enter a valid email address")
      return false
    }

    if (!notes.trim()) {
      Alert.alert("Error", "Please describe the changes you need")
      return false
    }

    return true
  }

  const handleSubmit = async () => {
    if (!validateForm()) return

    setLoading(true)
    try {
      // Get order ID
      const { data: orderData, error: orderError } = await supabase
        .from("orders")
        .select("id")
        .eq("reference_number", formData.referenceNumber)
        .single()

      if (orderError) throw orderError

      // Insert change request
      const { data: changeData, error: changeError } = await supabase
        .from("changes")
        .insert({
          order_id: orderData.id,
          email: formData.email,
          notes: formData.notes,
          deadline_changes: formData.deadlineChanges || null,
        })
        .select()
        .single()

      if (changeError) throw changeError

      // Upload files if any
      if (files.length > 0) {
        for (const file of files) {
          if (file.type === "success") {
            const filePath = `changes/${formData.referenceNumber}/${file.name}`

            const { error: fileError } = await supabase.from("change_files").insert({
              change_id: changeData.id,
              file_name: file.name,
              file_path: filePath,
              file_size: file.size,
              file_type: file.mimeType,
            })

            if (fileError) throw fileError
          }
        }
      }

      Alert.alert("Success!", "Your change request has been submitted successfully!", [
        {
          text: "OK",
          onPress: () => router.back(),
        },
      ])
    } catch (error) {
      console.error("Error submitting changes:", error)
      Alert.alert("Error", "Failed to submit change request. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  if (!orderExists) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text>Verifying reference number...</Text>
        </View>
      </SafeAreaView>
    )
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.content}>
          <Text style={styles.title}>Changes Request Form</Text>
          <Text style={styles.subtitle}>Request changes to your existing order</Text>

          <CustomInput
            label="📧 Email Address*"
            placeholder="Enter your email address"
            value={formData.email}
            onChangeText={(value) => handleInputChange("email", value)}
            keyboardType="email-address"
            autoCapitalize="none"
          />

          <CustomInput
            label="📋 Order Reference Number*"
            value={formData.referenceNumber}
            editable={false}
            style={styles.disabledInput}
          />

          <CustomInput
            label="📝 Notes*"
            placeholder="Describe the changes you need for your order"
            value={formData.notes}
            onChangeText={(value) => handleInputChange("notes", value)}
            multiline
            numberOfLines={4}
            style={styles.textArea}
          />

          <CustomInput
            label="⏰ Deadline Changes"
            placeholder="Specify any deadline changes needed (optional)"
            value={formData.deadlineChanges}
            onChangeText={(value) => handleInputChange("deadlineChanges", value)}
          />

          <FileUpload label="📎 Upload Additional Files (optional)" onFilesSelected={setFiles} maxFiles={5} />

          <CustomButton
            title="Submit Changes Request"
            onPress={handleSubmit}
            disabled={loading}
            style={styles.submitButton}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8FAFC",
  },
  scrollContent: {
    paddingBottom: 40,
  },
  content: {
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#1F2937",
    textAlign: "center",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: "#6B7280",
    textAlign: "center",
    marginBottom: 32,
  },
  textArea: {
    height: 100,
    textAlignVertical: "top",
  },
  disabledInput: {
    backgroundColor: "#F3F4F6",
    color: "#6B7280",
  },
  submitButton: {
    marginTop: 24,
    backgroundColor: "#EF4444",
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
})
