"use client"

import { useState, useEffect } from "react"
import { View, Text, StyleSheet, ScrollView, SafeAreaView, Alert } from "react-native"
import { CustomButton } from "../../components/CustomButton"
import { CustomInput } from "../../components/CustomInput"
import { FileUpload } from "../../components/FileUpload"
import { supabase } from "../../lib/supabase"
import { router, useLocalSearchParams } from "expo-router"
import type * as DocumentPicker from "expo-document-picker"

export default function WorkerFormScreen() {
  const { ref } = useLocalSearchParams<{ ref: string }>()
  const [formData, setFormData] = useState({
    email: "",
    referenceNumber: ref || "",
    notes: "",
  })
  const [files, setFiles] = useState<DocumentPicker.DocumentPickerResult[]>([])
  const [loading, setLoading] = useState(false)
  const [orderExists, setOrderExists] = useState(false)

  useEffect(() => {
    if (ref) {
      checkOrderExists(ref)
    }
  }, [ref])

  const checkOrderExists = async (referenceNumber: string) => {
    try {
      const { data, error } = await supabase
        .from("orders")
        .select("id")
        .eq("reference_number", referenceNumber)
        .single()

      if (data) {
        setOrderExists(true)
      } else {
        Alert.alert("Invalid Reference", "Order not found with this reference number")
        router.back()
      }
    } catch (error) {
      Alert.alert("Error", "Failed to verify reference number")
      router.back()
    }
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const validateForm = () => {
    const { email, notes } = formData

    if (!email.trim() || !email.includes("@")) {
      Alert.alert("Error", "Please enter a valid email address")
      return false
    }

    if (!notes.trim()) {
      Alert.alert("Error", "Please enter notes for the client")
      return false
    }

    if (files.length === 0) {
      Alert.alert("Error", "Please upload the completed work files")
      return false
    }

    return true
  }

  const handleSubmit = async () => {
    if (!validateForm()) return

    setLoading(true)
    try {
      // Get order ID
      const { data: orderData, error: orderError } = await supabase
        .from("orders")
        .select("id")
        .eq("reference_number", formData.referenceNumber)
        .single()

      if (orderError) throw orderError

      // Insert worker submission
      const { data: submissionData, error: submissionError } = await supabase
        .from("worker_submissions")
        .insert({
          order_id: orderData.id,
          email: formData.email,
          notes: formData.notes,
        })
        .select()
        .single()

      if (submissionError) throw submissionError

      // Upload files
      for (const file of files) {
        if (file.type === "success") {
          const filePath = `submissions/${formData.referenceNumber}/${file.name}`

          const { error: fileError } = await supabase.from("worker_files").insert({
            submission_id: submissionData.id,
            file_name: file.name,
            file_path: filePath,
            file_size: file.size,
            file_type: file.mimeType,
          })

          if (fileError) throw fileError
        }
      }

      Alert.alert("Success!", "Your work submission has been uploaded successfully!", [
        {
          text: "OK",
          onPress: () => router.back(),
        },
      ])
    } catch (error) {
      console.error("Error submitting work:", error)
      Alert.alert("Error", "Failed to submit work. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  if (!orderExists) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text>Verifying reference number...</Text>
        </View>
      </SafeAreaView>
    )
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.content}>
          <Text style={styles.title}>Worker Submission Form</Text>
          <Text style={styles.subtitle}>Submit your completed work</Text>

          <CustomInput
            label="📧 Email Address*"
            placeholder="Enter your email address"
            value={formData.email}
            onChangeText={(value) => handleInputChange("email", value)}
            keyboardType="email-address"
            autoCapitalize="none"
          />

          <CustomInput
            label="📋 Order Reference Number*"
            value={formData.referenceNumber}
            editable={false}
            style={styles.disabledInput}
          />

          <CustomInput
            label="💬 Notes for Client*"
            placeholder="Enter notes or messages for the client"
            value={formData.notes}
            onChangeText={(value) => handleInputChange("notes", value)}
            multiline
            numberOfLines={4}
            style={styles.textArea}
          />

          <FileUpload label="📎 Upload Completed Work*" onFilesSelected={setFiles} maxFiles={10} />

          <CustomButton title="Submit Work" onPress={handleSubmit} disabled={loading} style={styles.submitButton} />
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8FAFC",
  },
  scrollContent: {
    paddingBottom: 40,
  },
  content: {
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#1F2937",
    textAlign: "center",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: "#6B7280",
    textAlign: "center",
    marginBottom: 32,
  },
  textArea: {
    height: 100,
    textAlignVertical: "top",
  },
  disabledInput: {
    backgroundColor: "#F3F4F6",
    color: "#6B7280",
  },
  submitButton: {
    marginTop: 24,
    backgroundColor: "#10B981",
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
})
