import { Stack } from "expo-router"

export default function FormsLayout() {
  return (
    <Stack
      screenOptions={{
        headerStyle: {
          backgroundColor: "#3B82F6",
        },
        headerTintColor: "white",
        headerTitleStyle: {
          fontWeight: "bold",
        },
      }}
    >
      <Stack.Screen
        name="index"
        options={{
          title: "Select Form Type",
        }}
      />
      <Stack.Screen
        name="client"
        options={{
          title: "Client Form",
        }}
      />
      <Stack.Screen
        name="changes"
        options={{
          title: "Changes Form",
        }}
      />
      <Stack.Screen
        name="worker"
        options={{
          title: "Worker Form",
        }}
      />
    </Stack>
  )
}
