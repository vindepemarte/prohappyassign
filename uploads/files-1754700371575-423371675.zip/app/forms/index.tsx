"use client"

import { useState } from "react"
import { View, Text, StyleSheet, SafeAreaView, Alert } from "react-native"
import { CustomButton } from "../../components/CustomButton"
import { CustomInput } from "../../components/CustomInput"
import { router } from "expo-router"

export default function FormsScreen() {
  const [accessCode, setAccessCode] = useState("")

  const handleFormAccess = (formType: "client" | "changes" | "worker") => {
    if (formType === "client") {
      if (accessCode.toUpperCase() === "IVA98") {
        router.push("/forms/client")
      } else {
        Alert.alert("Invalid Code", "Please enter the correct access code for Client form")
      }
    } else {
      // For changes and worker forms, we need a 5-character reference number
      if (accessCode.length === 5) {
        if (formType === "changes") {
          router.push(`/forms/changes?ref=${accessCode.toUpperCase()}`)
        } else {
          router.push(`/forms/worker?ref=${accessCode.toUpperCase()}`)
        }
      } else {
        Alert.alert("Invalid Reference", "Please enter a valid 5-character reference number")
      }
    }
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.title}>Select Form Type</Text>
        <Text style={styles.subtitle}>Choose the appropriate form and enter your access code</Text>

        <View style={styles.inputContainer}>
          <CustomInput
            label="Access Code / Reference Number"
            value={accessCode}
            onChangeText={setAccessCode}
            placeholder="Enter code or reference number"
            autoCapitalize="characters"
          />
        </View>

        <View style={styles.buttonContainer}>
          <View style={styles.tabButton}>
            <Text style={styles.tabTitle}>👤 Client</Text>
            <Text style={styles.tabDescription}>New assignment submission</Text>
            <Text style={styles.tabCode}>Code: IVA98</Text>
            <CustomButton title="Access Client Form" onPress={() => handleFormAccess("client")} style={styles.button} />
          </View>

          <View style={styles.tabButton}>
            <Text style={styles.tabTitle}>🔄 Changes</Text>
            <Text style={styles.tabDescription}>Request changes to existing order</Text>
            <Text style={styles.tabCode}>5-character reference</Text>
            <CustomButton
              title="Access Changes Form"
              onPress={() => handleFormAccess("changes")}
              style={styles.button}
              variant="secondary"
            />
          </View>

          <View style={styles.tabButton}>
            <Text style={styles.tabTitle}>👨‍💼 Worker</Text>
            <Text style={styles.tabDescription}>Submit completed work</Text>
            <Text style={styles.tabCode}>5-character reference</Text>
            <CustomButton
              title="Access Worker Form"
              onPress={() => handleFormAccess("worker")}
              style={styles.button}
              variant="success"
            />
          </View>
        </View>
      </View>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8FAFC",
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#1F2937",
    textAlign: "center",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: "#6B7280",
    textAlign: "center",
    marginBottom: 32,
  },
  inputContainer: {
    marginBottom: 32,
  },
  buttonContainer: {
    gap: 20,
  },
  tabButton: {
    backgroundColor: "white",
    borderRadius: 16,
    padding: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  tabTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#1F2937",
    marginBottom: 8,
  },
  tabDescription: {
    fontSize: 14,
    color: "#6B7280",
    marginBottom: 8,
  },
  tabCode: {
    fontSize: 12,
    color: "#3B82F6",
    fontWeight: "600",
    marginBottom: 16,
  },
  button: {
    marginTop: 8,
  },
})
