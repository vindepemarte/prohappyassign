-- Create users table with roles
CREATE TABLE IF NOT EXISTS users (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT,
  role TEXT DEFAULT 'client' CHECK (role IN ('client', 'agent', 'worker', 'god')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  reference_number TEXT UNIQUE NOT NULL,
  client_id UUID REFERENCES users(id),
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  module_name TEXT NOT NULL,
  word_count INTEGER NOT NULL,
  deadline DATE NOT NULL,
  additional_guidance TEXT,
  status TEXT DEFAULT 'processing' CHECK (status IN ('processing', 'reviewing', 'done')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create order_files table
CREATE TABLE IF NOT EXISTS order_files (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size INTEGER,
  file_type TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create changes table
CREATE TABLE IF NOT EXISTS changes (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id UUID REFERENCES orders(id),
  email TEXT NOT NULL,
  notes TEXT NOT NULL,
  deadline_changes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create change_files table
CREATE TABLE IF NOT EXISTS change_files (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  change_id UUID REFERENCES changes(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size INTEGER,
  file_type TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create worker_submissions table
CREATE TABLE IF NOT EXISTS worker_submissions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id UUID REFERENCES orders(id),
  email TEXT NOT NULL,
  notes TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create worker_files table
CREATE TABLE IF NOT EXISTS worker_files (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  submission_id UUID REFERENCES worker_submissions(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size INTEGER,
  file_type TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE changes ENABLE ROW LEVEL SECURITY;
ALTER TABLE change_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE worker_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE worker_files ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own data" ON users FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update their own data" ON users FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can view their own orders" ON orders FOR SELECT USING (client_id = auth.uid());
CREATE POLICY "Users can insert orders" ON orders FOR INSERT WITH CHECK (true);

CREATE POLICY "Users can view order files" ON order_files FOR SELECT USING (true);
CREATE POLICY "Users can insert order files" ON order_files FOR INSERT WITH CHECK (true);

CREATE POLICY "Users can view changes" ON changes FOR SELECT USING (true);
CREATE POLICY "Users can insert changes" ON changes FOR INSERT WITH CHECK (true);

CREATE POLICY "Users can view change files" ON change_files FOR SELECT USING (true);
CREATE POLICY "Users can insert change files" ON change_files FOR INSERT WITH CHECK (true);

CREATE POLICY "Users can view worker submissions" ON worker_submissions FOR SELECT USING (true);
CREATE POLICY "Users can insert worker submissions" ON worker_submissions FOR INSERT WITH CHECK (true);

CREATE POLICY "Users can view worker files" ON worker_files FOR SELECT USING (true);
CREATE POLICY "Users can insert worker files" ON worker_files FOR INSERT WITH CHECK (true);
