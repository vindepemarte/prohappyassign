"use client"

import type React from "react"
import { useState } from "react"
import { View, Text, TouchableOpacity, StyleSheet, Alert } from "react-native"
import * as DocumentPicker from "expo-document-picker"
import { Ionicons } from "@expo/vector-icons"

interface FileUploadProps {
  onFilesSelected: (files: DocumentPicker.DocumentPickerResult[]) => void
  maxFiles?: number
  maxSizePerFile?: number
  label: string
}

export const FileUpload: React.FC<FileUploadProps> = ({
  onFilesSelected,
  maxFiles = 5,
  maxSizePerFile = 100 * 1024 * 1024, // 100MB
  label,
}) => {
  const [selectedFiles, setSelectedFiles] = useState<DocumentPicker.DocumentPickerResult[]>([])

  const pickFiles = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: [
          "application/pdf",
          "application/msword",
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
          "application/vnd.ms-excel",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          "application/vnd.ms-powerpoint",
          "application/vnd.openxmlformats-officedocument.presentationml.presentation",
          "text/*",
          "image/*",
        ],
        multiple: true,
        copyToCacheDirectory: true,
      })

      if (!result.canceled) {
        const validFiles = result.assets.filter((file) => {
          if (file.size && file.size > maxSizePerFile) {
            Alert.alert("File Too Large", `${file.name} is larger than 100MB`)
            return false
          }
          return true
        })

        if (selectedFiles.length + validFiles.length > maxFiles) {
          Alert.alert("Too Many Files", `You can only upload up to ${maxFiles} files`)
          return
        }

        const newFiles = [...selectedFiles, ...validFiles]
        setSelectedFiles(newFiles)
        onFilesSelected(newFiles)
      }
    } catch (error) {
      Alert.alert("Error", "Failed to pick files")
    }
  }

  const removeFile = (index: number) => {
    const newFiles = selectedFiles.filter((_, i) => i !== index)
    setSelectedFiles(newFiles)
    onFilesSelected(newFiles)
  }

  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}</Text>

      <TouchableOpacity style={styles.uploadButton} onPress={pickFiles}>
        <Ionicons name="cloud-upload-outline" size={24} color="#3B82F6" />
        <Text style={styles.uploadText}>
          {selectedFiles.length === 0 ? "No file chosen" : `${selectedFiles.length} file(s) selected`}
        </Text>
        <Text style={styles.uploadSubtext}>Click to upload or drag and drop</Text>
      </TouchableOpacity>

      <Text style={styles.helpText}>
        PDF, Word, Excel, PowerPoint, text, or image files up to 100MB each (max {maxFiles} files)
      </Text>

      {selectedFiles.length > 0 && (
        <View style={styles.fileList}>
          {selectedFiles.map((file, index) => (
            <View key={index} style={styles.fileItem}>
              <Text style={styles.fileName} numberOfLines={1}>
                {file.name}
              </Text>
              <TouchableOpacity onPress={() => removeFile(index)}>
                <Ionicons name="close-circle" size={20} color="#EF4444" />
              </TouchableOpacity>
            </View>
          ))}
        </View>
      )}
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: "600",
    color: "#374151",
    marginBottom: 8,
  },
  uploadButton: {
    borderWidth: 2,
    borderColor: "#D1D5DB",
    borderStyle: "dashed",
    borderRadius: 12,
    paddingVertical: 24,
    paddingHorizontal: 16,
    alignItems: "center",
    backgroundColor: "#F9FAFB",
  },
  uploadText: {
    fontSize: 16,
    color: "#374151",
    marginTop: 8,
    fontWeight: "500",
  },
  uploadSubtext: {
    fontSize: 14,
    color: "#6B7280",
    marginTop: 4,
  },
  helpText: {
    fontSize: 12,
    color: "#6B7280",
    marginTop: 8,
    textAlign: "center",
  },
  fileList: {
    marginTop: 12,
  },
  fileItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: "#F3F4F6",
    borderRadius: 8,
    marginBottom: 8,
  },
  fileName: {
    flex: 1,
    fontSize: 14,
    color: "#374151",
  },
})
