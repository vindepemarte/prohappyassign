import type React from "react"
import { View, Text, TextInput, StyleSheet, type TextInputProps } from "react-native"

interface CustomInputProps extends TextInputProps {
  label: string
  error?: string
  icon?: string
}

export const CustomInput: React.FC<CustomInputProps> = ({ label, error, icon, style, ...props }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.label}>
        {icon && `${icon} `}
        {label}
      </Text>
      <TextInput style={[styles.input, error && styles.inputError, style]} placeholderTextColor="#9CA3AF" {...props} />
      {error && <Text style={styles.errorText}>{error}</Text>}
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: "600",
    color: "#374151",
    marginBottom: 8,
  },
  input: {
    borderWidth: 2,
    borderColor: "#E5E7EB",
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    backgroundColor: "white",
    minHeight: 48,
  },
  inputError: {
    borderColor: "#EF4444",
  },
  errorText: {
    color: "#EF4444",
    fontSize: 12,
    marginTop: 4,
  },
})
